var myWindow;
function calculateTax()
{


var tl= document.empForm.title.value;
var first_nm= document.empForm.fname.value;
var last_nm= document.empForm.lname.value;

var grs_sal= document.empForm.gross.value;

var adr= document.empForm.addr.value;

var tax_perc;
var net_sal;

if(grs_sal<180000)
{
	tax_perc= 0;
}

else if((grs_sal>=180000)&&(grs_sal<=300000))
{
	tax_perc= 10;
}

else if((grs_sal>=300001)&&(grs_sal<=500000))
{
	tax_perc= 20;
}

else{
	tax_perc= 30;
}

var tax= grs_sal*(tax_perc/100);
net_sal= grs_sal-tax;

document.write("<br>");
document.write("salary:"+net_sal);


 myWindow = window.open("", "MsgWindow", "width=500,height=500");
	 
myWindow.document.write("<p align=center>Income Tax</p>");
	  
	  myWindow.document.write("<table border=1 align= center><tr> <td>Name</td> <td>Gross Salary</td> <td>Tax Percent</td> <td>Income tax</td> <td>Net Salary</td> </tr>");
	  
	  myWindow.document.write("<tr><td>"+first_nm+" "+last_nm+" </td> <td>"+grs_sal +"</td><td>"+tax_perc+"</td> <td>"+tax +"</td> <td>"+net_sal+"</td> </tr>");
 myWindow.document.write("</table>");
	  
	  
	  
	  
	  
	  
	  
  
	  }