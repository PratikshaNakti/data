package com.cg.onlineTicket.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.onlineTicket.dto.ShowDetail;
import com.cg.onlineTicket.exceptions.OnlineBookingException;
import com.cg.onlineTicket.service.ITicketBookingService;
import com.cg.onlineTicket.service.TicketBookingServiceImpl;

@WebServlet("*.do")
public class BookingController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	ITicketBookingService ticketService;
	private RequestDispatcher dispatch;
    private String nextJsp;
    private String message= null;
    
	public BookingController(){
		ticketService= new TicketBookingServiceImpl();
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}
	
	private void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path= request.getServletPath();
		System.out.println(path);
		
		//Display all shows
		if(path.equals("/displyAll.do")){
			System.out.println("Inside showAll");
			List<ShowDetail> myList=null;
			try {
				myList= ticketService.showAll();
				
				HttpSession session= request.getSession(true);
				System.out.println("Your session Id is : "+session.getId());
				session.setAttribute("shows", myList);
				nextJsp="/showDetails.jsp";
			} 
			catch (OnlineBookingException e) {
				// TODO Auto-generated catch block
				message= "Error while showing  data";
				request.setAttribute("errorMsg", message);
				nextJsp= "/error.jsp";
				//e.printStackTrace();
			}
			
			
		}
		
		//get booking form 
		else if(path.equals("/book.do")){
			
			
			String data= request.getQueryString();
					String showId = data.substring(3,7);
			
					
					try {
						ShowDetail myShow= ticketService.getShow(showId);
						
						System.out.println("Show Name: "+myShow.getShowName());
						
						System.out.println("Price: "+myShow.getTicketPrice());
					
						request.setAttribute("dataShow", myShow);
						nextJsp= "/bookNow.jsp";
						
					} catch (OnlineBookingException e) {
						
						message= "Error while booking show ";
						request.setAttribute("errorMsg", message);
						nextJsp= "/error.jsp";
						//e.printStackTrace();
					}
					
					
					
					
		}
		
		//book show
		else if(path.equals("/bookShow.do")){
			
			String avlSeatsStr= request.getParameter("seatsAvl");
			String bookSeatsStr=  request.getParameter("num_seats");
			int avlSeats= Integer.parseInt(avlSeatsStr);
			int bookSeats= Integer.parseInt(bookSeatsStr);
			
			System.out.println(avlSeats+",  "+bookSeats);
			if(avlSeats >= bookSeats){
				System.out.println("Eligible booking");
				
				String showNm= request.getParameter("show_nm");
				String priceStr=  request.getParameter("show_Price");
				float price= Float.parseFloat(priceStr);
				String custName=  request.getParameter("cust_nm");
				String mobNo=  request.getParameter("mobile_no");
				
				float totalPrice= price*bookSeats;
				try {
					
					int message= ticketService.updateSeats(showNm, avlSeats, bookSeats);
					if(message>0){
						
						request.setAttribute("ShowName", showNm);
						request.setAttribute("Price", totalPrice);
						request.setAttribute("CustName", custName);
						request.setAttribute("Mobile", mobNo);
						request.setAttribute("RequestSeats", bookSeats);
						request.setAttribute("TotalPrc", totalPrice);
						nextJsp= "/success.jsp";
						
					}
					
				} catch (OnlineBookingException e) {
					// TODO Auto-generated catch block
					
					message= "Error while updating seat availability ";
					request.setAttribute("errorMsg", message);
					nextJsp= "/error.jsp";
					//e.printStackTrace();
				}
				
			}
			else{
				message= "Number of seats to be booked should be lesser than available no of seats";
				request.setAttribute("errorMsg", message);
				nextJsp= "/error.jsp";
			}
			
		}
		
		dispatch= request.getRequestDispatcher(nextJsp);
		dispatch.forward(request, response);
		
	}

}
