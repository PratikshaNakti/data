package com.cg.onlineTicket.exceptions;

public class OnlineBookingException extends Exception {

	public OnlineBookingException() {
		
	}

	public OnlineBookingException(String message) {
		super(message);
		
	}

	public OnlineBookingException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public OnlineBookingException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public OnlineBookingException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

}
