package com.cg.onlineTicket.dao;

import java.util.List;

import com.cg.onlineTicket.dto.ShowDetail;
import com.cg.onlineTicket.exceptions.OnlineBookingException;



public interface ITicketBookingDao {

	public List<ShowDetail> showAll() throws OnlineBookingException;
	public ShowDetail getShow(String showId)  throws OnlineBookingException;
	
	public int updateSeats(String showName, int avlSeats, int bookSeats) throws OnlineBookingException;
}
