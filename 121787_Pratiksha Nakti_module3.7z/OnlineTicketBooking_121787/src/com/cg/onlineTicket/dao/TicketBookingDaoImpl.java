package com.cg.onlineTicket.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.onlineTicket.dto.ShowDetail;
import com.cg.onlineTicket.exceptions.OnlineBookingException;
import com.cg.onlineTicket.util.DbUtil;

public class TicketBookingDaoImpl implements ITicketBookingDao{

	Connection conn= null;
	public TicketBookingDaoImpl() {
		
	}
	@Override
	public List<ShowDetail> showAll() throws OnlineBookingException {
		List<ShowDetail> myShow= new ArrayList<ShowDetail>();
		PreparedStatement pstm1= null;
		String showQry= "SELECT ShowId, ShowName, Location, ShowDate, AvSeats, PriceTicket FROM ShowDetails";
		
		conn= DbUtil.obtainConnection();
		try {
			pstm1= conn.prepareStatement(showQry);
			ResultSet res1= pstm1.executeQuery();
			
			while(res1.next()){
				ShowDetail show= new ShowDetail();
				
				show.setShowId(res1.getString("ShowId"));
				show.setShowName(res1.getString("ShowName"));
				show.setLocation(res1.getString("Location"));
				show.setShowDate(res1.getDate("ShowDate"));
				show.setAvlSeats(res1.getInt("AvSeats"));
				show.setTicketPrice(res1.getFloat("PriceTicket"));
				
				myShow.add(show);
				
			}
		} catch (SQLException e) {
			
			//e.printStackTrace();
		}
		finally{
			if(pstm1!=null){
				try {
					pstm1.close();
				} catch (SQLException e) {
					
					//e.printStackTrace();
				}
				
				if(conn!=null){
					try {
						conn.close();
					} catch (SQLException e) {
						
						//e.printStackTrace();
					}
				}
			}
		}
		
		return myShow;
	}
	@Override
	public ShowDetail getShow(String showId) throws OnlineBookingException {
		PreparedStatement pstm2= null;
		ShowDetail showData= new ShowDetail();
		
		String getQry= "SELECT ShowId, ShowName, Location, ShowDate, AvSeats, PriceTicket FROM ShowDetails WHERE ShowId=?";
		
		
		try {
			conn= DbUtil.obtainConnection();
			pstm2= conn.prepareStatement(getQry);
			pstm2.setString(1, showId);
			ResultSet res2= pstm2.executeQuery();
			
			while(res2.next()){
				
				showData.setShowId(res2.getString("ShowId"));
				showData.setShowName(res2.getString("ShowName"));
				showData.setLocation(res2.getString("Location"));
				showData.setShowDate(res2.getDate("ShowDate"));
				showData.setAvlSeats(res2.getInt("AvSeats"));
				showData.setTicketPrice(res2.getFloat("PriceTicket"));
				
				
			}
			
		} catch (SQLException e) {
			
			//e.printStackTrace();
		}
		
		finally{
			if(pstm2!=null){
				try {
					pstm2.close();
				} catch (SQLException e) {
					
					//e.printStackTrace();
				}
				
				if(conn!=null){
					try {
						conn.close();
					} catch (SQLException e) {
						
						//e.printStackTrace();
					}
				}
			}
		}
		
		return showData;
	}
	
	
	@Override
	public int updateSeats(String showName, int avlSeats, int bookSeats)
			throws OnlineBookingException {
		PreparedStatement pstm3= null;
		int newSeats= avlSeats-bookSeats;
		int msg=0;
		String updtQry= "UPDATE ShowDetails SET AvSeats=? WHERE ShowName=?";
			
		try {
			conn= DbUtil.obtainConnection();
			pstm3= conn.prepareStatement(updtQry);
			
			pstm3.setInt(1, newSeats);
			pstm3.setString(2, showName);
			int status= pstm3.executeUpdate();
			
			if(status>0){
				msg= 1;
			}
			System.out.println("After updation, no.of seats available:"+newSeats);
			
		} catch (SQLException e) {
			
			//e.printStackTrace();
		}
		
		finally{
			if(pstm3!=null){
				try {
					pstm3.close();
				} catch (SQLException e) {
					
					//e.printStackTrace();
				}
				
				if(conn!=null){
					try {
						conn.close();
					} catch (SQLException e) {
						
						//e.printStackTrace();
					}
				}
			}
		}

		
		return msg;
	}

}
