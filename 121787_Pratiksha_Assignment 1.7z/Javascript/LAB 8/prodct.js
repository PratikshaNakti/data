var myWindow;
function showProd()
{ 
//alert('hi');

	var d= document.form_prod.catgry.selectedIndex;
	
	
	if(d==0)
	{
		var e1= new Option();
		e1.value="Television";
		e1.text="Television";
		document.form_prod.products.options[0]=e1;
		
		var e2= new Option();
		e2.value="Laptop";
		e2.text="Laptop";
		document.form_prod.products.options[1]=e2;
		
		var e3= new Option();
		e3.value="Phone";
		e3.text="Phone";
		document.form_prod.products.options[2]=e3;
		
	}
	
	else if(d==1)
	{
		var g1= new Option();
		g1.value="Soap";
		g1.text="Soap";
		document.form_prod.products.options[0]=g1;
		
		var g2= new Option();
		g2.value="Powder";
		g2.text="Powder";
		document.form_prod.products.options[1]=g2;
	}
	
	else{
		document.write('nothing');
	}


}

function price()
{
	var prc_tv=20000;
	var prc_lp=30000;
	var prc_ph=10000;
	var prc_soap=40;
	var prc_pwd=90;
	var total;
	
	var qt= document.form_prod.prod.value;
	
	if(document.form_prod.products.value=="Television")
	{
		total= qt*prc_tv;
		document.form_prod.bill.value = total;
	}
	
	else if(document.form_prod.products.value=="Laptop")
	{
		total= qt*prc_lp;
		document.form_prod.bill.value = total;
	}
	
	else if(document.form_prod.products.value=="Phone")
	{
		total= qt*prc_ph;
		document.form_prod.bill.value = total;
	}
	
	else if(document.form_prod.products.value=="Soap")
	{
		total= qt*prc_soap;
		document.form_prod.bill.value = total;
	}
	
	else if(document.form_prod.products.value=="Powder")
	{
		total= qt*prc_pwd;
		document.form_prod.bill.value = total;
	}
}
