
function myfunction()
{ 
       var p= parseInt(  document.getElementById("loan").value);
	         var r=parseInt (document.getElementById("rate").value);
			        var t=  parseInt( document.getElementById("year").value);
					
if(p<1500000){	
if(t>=7 & t<=15)	{
					var si=(p*t*r)/100
					
					var m =(p+si)/(12*t);
					
					var t=p+si;
					
					 document.getElementById("monthly").value=m;
					  document.getElementById("total").value=t;
					   document.getElementById("intpayment").value=si;
}
else{
	alert('Repayment period should be between 7 yrs to 15 yrs')
}
}
else
{
	alert('MAXIMUM LOAN AMOUNT IS 1500000')
	}
             


}