package com.capgemini.btb.junittest;
import static org.junit.Assert.*;


import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.btb.dao.BusDaoImpl;
import com.capgemini.btb.dao.IBusDao;
import com.capgemini.btb.exception.BookingException;



public class TestBusDaoShow {
	IBusDao ibus;

	@Before
	public void setUp() throws Exception {
		ibus= new BusDaoImpl();
	}

	@After
	public void tearDown() throws Exception {
		ibus= null;
	}

	@Test
	public void testRetrieveBusDetails() {
		try {
			
			assertNotNull(ibus.retrieveBusDetails());
		} catch (BookingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
