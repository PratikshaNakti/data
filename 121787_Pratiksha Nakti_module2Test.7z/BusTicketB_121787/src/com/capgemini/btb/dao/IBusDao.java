package com.capgemini.btb.dao;

import java.util.ArrayList;

import com.capgemini.btb.bean.BookingBean;
import com.capgemini.btb.bean.BusBean;
import com.capgemini.btb.exception.BookingException;

public interface IBusDao {
	ArrayList<BusBean> retrieveBusDetails() throws BookingException;
	int bookTicket(BookingBean bookingBean) throws BookingException;

}
