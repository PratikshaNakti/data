package com.capgemini.btb.service;

import java.util.ArrayList;

import com.capgemini.btb.bean.BookingBean;
import com.capgemini.btb.bean.BusBean;
import com.capgemini.btb.dao.BusDaoImpl;
import com.capgemini.btb.dao.IBusDao;
import com.capgemini.btb.exception.BookingException;

public class BusServiceImpl implements IBusService {
	IBusDao iBus= new BusDaoImpl();

	@Override
	public ArrayList<BusBean> retrieveBusDetails() throws BookingException {
		
		return iBus.retrieveBusDetails();
	}

	@Override
	public int bookTicket(BookingBean bookingBean) throws BookingException {
	
		return iBus.bookTicket(bookingBean);
	}

}
