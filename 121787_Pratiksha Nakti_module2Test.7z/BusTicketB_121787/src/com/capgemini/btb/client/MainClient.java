package com.capgemini.btb.client;


import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;

import com.capgemini.btb.bean.BookingBean;
import com.capgemini.btb.bean.BusBean;
import com.capgemini.btb.exception.BookingException;
import com.capgemini.btb.service.BusServiceImpl;
import com.capgemini.btb.service.IBusService;


public class MainClient {

	private static final Logger mylogger=
			Logger.getLogger(MainClient.class);
	
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		Scanner sc2 = new Scanner(System.in);
		IBusService impl= new BusServiceImpl();  
		
		String cusId;
		int reqSeats;
		int bus_ID;
		
		boolean res_id;
		boolean res_seats;
		
		int ch;
		do{
			printDetail();
			System.out.println("Select number of your choice");

			ch = sc.nextInt();
			switch(ch){
			case 1: 
				ArrayList<BusBean> buslist;
				try {
					buslist = impl.retrieveBusDetails();
					System.out.println("Showing all the available buses: ");
					System.out.println("BusId  "+ "BusType"+"  FromStop"+" ToStop"+" Avlb Seats"+" Fare"+" Dt of journey");
					for(BusBean b: buslist){
						//System.out.println(b);
						
						
					System.out.print(b.getBusId()+" "+b.getBusType()+" "+b.getFromStop()+" "+b.getToStop()+" "+b.getAvailableSeats()+" "+b.getFare()+" ");
					LocalDate dt= b.getDoj();
					System.out.print(dt);
					System.out.println();
					}
					System.out.println();
					
					//Cust Id validation
					do{
						
					System.out.println("Enter customer ID e.g A111111");
					cusId= sc2.nextLine();
					
					Pattern pattern2= Pattern.compile("^[A-Z]{1}[0-9]{6}");
					Matcher matcher2 = pattern2.matcher(cusId);		
					 res_id= matcher2.matches();
					 if(res_id== false){
							System.out.println("Customer ID is not valid. Please enter valid one");
						}
					}while(res_id!=true);
					
					//Bus Id validation
					
						System.out.println("Enter Bus ID");
						bus_ID= sc.nextInt();
						
						do{
						System.out.println("Enter No of seats:");
						reqSeats= sc.nextInt();
						if((reqSeats<=0) || (reqSeats>30)){
							res_seats= false;
							System.out.println("Required no of seats cannot be 0 and should be less than 30");
						}
						else{
							res_seats= true;
						}
						}while(res_seats!= true);
						
						BookingBean bookingBn= new BookingBean(reqSeats, bus_ID, cusId);
						if(res_id== true){
							int res= impl.bookTicket(bookingBn);
							if(res>0){
								int id= bookingBn.getBookingId();
								System.out.println("Thank you. Your Booking is done!");
								System.out.println("Your Booking Id is: "+id);
							}
						}
						
					
					
					//int result= impl.bookTicket(bookingBean)
				} catch (BookingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
				
			case 2: 
				System.exit(0);
				break;
				
			}
			
		}while(ch!=2);

	}
	
	public static void printDetail(){
		System.out.println("**********");
		System.out.println("1. Book Ticket");
		System.out.println("2. Exit");

		System.out.println("***********");
	}

}
