package lab2_5;
import java.util.*;

public class lab2_5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Gender gender=null;
		Person5 person51= new Person5();
		
		person51.setFirstname("Ankita");
		person51.setLastname("Rane");
		System.out.println("Enter phonr num:");
		Scanner sc= new Scanner(System.in);
		
		String pno= sc.next();
		person51.setPh(pno);
		
		System.out.println("Enter gender:");
		String gen= sc.next();
		
		gender= gender.valueOf(gen);
		person51.setGender(gender);
		
		person51.show();
		

	}

}
