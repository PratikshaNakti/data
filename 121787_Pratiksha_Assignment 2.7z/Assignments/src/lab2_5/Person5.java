package lab2_5;

public class Person5 {
	String firstname;
	String lastname;
	Gender gender;
	String ph;
	
	

	
	public Gender getGender() {
		return gender;
	}



	public void setGender(Gender gender) {
		this.gender = gender;
	}


/*
	public Person5(String firstname, String lastname, Gender gender, String ph) {
		super();
		this.firstname = firstname;
		this.lastname = lastname;
		this.gender = gender;
		this.ph = ph;
	}*/



	public Person5() {
		super();
	}



	public String getFirstname() {
		return firstname;
	}



	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}



	public String getLastname() {
		return lastname;
	}



	public void setLastname(String lastname) {
		this.lastname = lastname;
	}



	



	public String getPh() {
		return ph;
	}



	public void setPh(String ph) {
		this.ph = ph;
	}



	public void show(){
		System.out.println("Person Details :");
		System.out.println("First Name:"+firstname);
		System.out.println("Last Name:"+lastname);
		System.out.println("Gender:"+gender);
		System.out.println("Phone :"+ph);
	}

}
