package lab7_1;

import java.util.*;

public class lab7_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		String products[] = new String[5];
		int len = products.length;
		System.out.println("Enter 5 product names:");
		for (int i = 0; i < len; i++) {
			products[i] = sc.nextLine();

		}

		System.out.println();
		Arrays.sort(products);
		System.out.println("After Sorting the array:");
		System.out.println();

		for (int i = 0; i < len; i++) {
			System.out.println(products[i]);
		}

	}

}
