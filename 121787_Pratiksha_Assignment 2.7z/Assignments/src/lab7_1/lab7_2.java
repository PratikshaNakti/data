package lab7_1;
import java.util.*;
public class lab7_2 {

	public static void main(String[] args) {
		ArrayList<String> products= new ArrayList<String>();
		products.add("Lenovo Vibe K5");
		products.add("One Plus");
		products.add("Moto G4 Plus");
		products.add("IPhone 6S");
		products.add("LeEco 1 S");
		
		System.out.println("Before sorting :"+products);
		System.out.println();
		
		Collections.sort(products);
		System.out.println("After sorting :");
		
		for(String pd : products ){
			System.out.println(pd);
			
		}


	}

}
