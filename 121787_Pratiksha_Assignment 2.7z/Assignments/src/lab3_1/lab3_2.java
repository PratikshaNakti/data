package lab3_1;
import java.util.*;
public class lab3_2 {

	public static void main(String[] args) {
		String str;
		 boolean res= true;
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter a string :");
		str= sc.nextLine();
		char chArray[]= str.toCharArray();
		int len=chArray.length;
		for(int i=0; i<len; i++){
			for(int j=i+1; j<len; j++){
				if(chArray[i]>chArray[j]){
					res= false;
				}
			}
		}
		System.out.println("Result for positive string is :"+res);
	
	}

}
