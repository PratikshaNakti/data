package lab3_1;
import java.util.*;
public class lab3_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter a string");
		String str= sc.nextLine();
		int len= str.length();
		int choice;
		System.out.println("Enter your choice(number)");
		System.out.println("1. Add the string to itself");
		System.out.println("2. Replace odd positions with #");
		System.out.println("3. Remove duplicate characters");
		System.out.println("4. Change odd characters to uppercase");
		choice= sc.nextInt();
		switch(choice){
		case 1:
			String res= str+str;
			System.out.println(res);
			break;
			
		case 2:
			StringBuilder sb = new StringBuilder(str);
			for(int i=0;i<len;i++){
				int pos= i+1;
				if(pos%2!=0)
				{
					sb.setCharAt(i, '#');
					
				}
			}
			System.out.println("String after change:"+sb);
			
			break;
			
			
		case 3:
			String str2= str;
			int l= str2.length();
			String result= "";
			for(int j=0; j<l; j++){
				char ch= str2.charAt(j);
				result=result+ch;
				
				str2= str2.replace(ch, '\0');
			}
			 System.out.println("String after removing duplicate characters : " + result);
	
			break;
			
		case 4:
			StringBuilder sbr = new StringBuilder(str);
			String result4= "";
			for(int i=0;i<len;i++){
				int pos= i+1;
				if(pos%2!=0)
				{
					String st="";
					char chr= sbr.charAt(i);
					st= st+chr;
					st=st.toUpperCase();
					result4= result4+st;
					if(i<len-1){
						result4=result4+sbr.charAt(i+1);
					}
						
				}
				
				
			}
			System.out.println("String after change:"+result4);
			
			break;
			
			
			
			
			
		default:
			System.out.println("Wrong choice");
			
	
			
			
		}
		

	}

}
