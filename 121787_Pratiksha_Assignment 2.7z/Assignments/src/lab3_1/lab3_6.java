package lab3_1;
import java.util.*;
import java.time.ZoneId;
import java.time.ZonedDateTime;

public class lab3_6 {

	public static void main(String[] args) {
		
		Scanner sc= new Scanner(System.in);
		ZonedDateTime here= ZonedDateTime.now();
		System.out.println("India : "+here);
		System.out.println("Enter the zone");
		String zn= sc.nextLine();
		
		ZonedDateTime op= ZonedDateTime.now(ZoneId.of(zn));
		System.out.println("Time of entered zone is : "+op);
		

	}

}
