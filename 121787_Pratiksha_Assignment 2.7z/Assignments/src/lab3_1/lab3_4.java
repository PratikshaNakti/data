package lab3_1;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class lab3_4 {
	
	public static void getPeriod(String fDt, String sDt){
		DateTimeFormatter formatter= DateTimeFormatter.ofPattern("dd-MM-yyyy");
		LocalDate date1= LocalDate.parse(fDt, formatter);
		System.out.println("First Date is :"+date1);
		LocalDate date2= LocalDate.parse(sDt, formatter);
		System.out.println("Second Date is :"+date2);
		
		if(date1.isBefore(date2)){
			Period prd= date1.until(date2);
			
			System.out.println("Printing period from first given date to second given date :");
			System.out.println("Days :"+prd.getDays()+" , Months:"+prd.getMonths()+" , Years:"+prd.getYears());  
			
			
		}
		else{
			System.out.println("Date order is wrong");
		}
	
		
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
		String fDate;
		String sDate;
		
		System.out.println("Enter first date: ");
		fDate=sc.nextLine();
		System.out.println("Enter second date: ");
		sDate=sc.nextLine();
		
		getPeriod(fDate, sDate);
		

	}

}
