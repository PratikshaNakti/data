package lab3_1;

import java.util.*;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;

public class lab3_3 {
	
	public static void calculatePeriod(String sDate){
		
		DateTimeFormatter formatter= DateTimeFormatter.ofPattern("dd-MM-yyyy");  
		LocalDate userDate= LocalDate.parse(sDate, formatter);
		System.out.println("Given date is: "+userDate);
		LocalDate today= LocalDate.now();
		System.out.println("Today is: "+today);
		Period prd= userDate.until(today);
		System.out.println("Printing period from given date to today :");
		System.out.println("Days :"+prd.getDays()+" , Months:"+prd.getMonths()+" , Years:"+prd.getYears());  
		

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
		String stDate;
		System.out.println("Enter a date :");
		stDate=sc.nextLine();
		
		calculatePeriod(stDate);
		

	}

}
