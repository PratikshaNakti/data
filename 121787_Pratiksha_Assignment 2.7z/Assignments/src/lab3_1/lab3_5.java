package lab3_1;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class lab3_5 {
	
	public static void calcPeriod(String dt, int y, int m){
		
		//DateTimeFormatter formatter= DateTimeFormatter.ofPattern("MMM yyyy");
		DateTimeFormatter formatter=  DateTimeFormatter.ofPattern("dd-MM-yyyy");
		LocalDate date1= LocalDate.parse(dt, formatter);
		System.out.println("Purchase Date is :"+date1);
		int yr=y;
		int mon=m;
		LocalDate date2= date1.plusYears(yr);
		LocalDate date3= date2.plusMonths(mon);
		System.out.println("Warrenty expiry date: "+date3);
		
		
		
	}

	public static void main(String[] args) {
		String purchaseDate;
		int yrs;
		int mn;
		
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter purchase Date:(Month-Year)");
		purchaseDate= sc.nextLine();
		System.out.println("Enter warantee period year :");
		yrs= sc.nextInt();
		System.out.println("Enter warantee period month :");
		mn= sc.nextInt();
		
		calcPeriod(purchaseDate, yrs, mn);
		
		

	}

}
