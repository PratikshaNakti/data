package lab8_1;
import java.util.*;

import java.io.*;

public class lab8_2 {

	public static void main(String[] args) {
		
		
		int i;
		try(FileReader fin= new FileReader("D:\\pnakti_demo\\files\\numbers.txt") ){  

			 Scanner src = new Scanner(fin); 

			while(src.hasNext()){
	
				if(src.hasNextInt()){
					i= src.nextInt();
						if(((i%2)==0) && (i!=0) ){
							System.out.println("Even found: "+i);
						}
					
					
				}
			}
			
		}
		
		catch(Exception e){
			System.out.println(e);
		}

	}

}
