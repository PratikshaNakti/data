package lab8_1;

import java.io.*;

public class lab8_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		File f = new File("D:\\pnakti_demo\\files\\sample.txt");

		try (FileReader fr = new FileReader(
				"D:\\pnakti_demo\\files\\sample.txt");
				FileWriter fw = new FileWriter(
						"D:\\pnakti_demo\\files\\newCopy.txt")) {

			int ch;
			int i = 0;
			int len = (int) f.length();
			System.out.println("Lenght:" + len);
			char chr[] = new char[len];
			ch = fr.read();

			while (ch != -1) {
				chr[i] = (char) ch;
				i++;

				System.out.print((char) ch);
				ch = fr.read();

			}

			for (int j = (chr.length) - 1; j >= 0; j--) {
				fw.write(chr[j]);

			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
