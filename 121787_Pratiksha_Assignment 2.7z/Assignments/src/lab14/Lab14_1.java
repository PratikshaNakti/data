package lab14;

public class Lab14_1{

public static void main(String[] args) {

Ilab14_1 im= (x,y) -> Math.pow(x, y);

double result=im.power(4,2);

System.out.println(result);

}

}
