package lab14;

@FunctionalInterface

public interface Ilab14_1 {

public double power(double x,double y);

}