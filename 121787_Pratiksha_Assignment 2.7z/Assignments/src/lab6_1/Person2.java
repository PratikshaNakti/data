package lab6_1;

public class Person2 {

	String firstname;
	String lastname;
	char gender;
	
	
	public Person2() {
		super();
	}
	
	
	public Person2(String firstname, String lastname, char gender) throws NameException {
		super();
		if(firstname.length()!=0){
		this.firstname = firstname;
		}
		else{
			throw new NameException("First name should not be empty");
		}
		if(lastname.length()!=0){
		this.lastname = lastname;
		}
		else{
			throw new NameException("Last name should not be empty");
		}
		
		this.gender = gender;
	}


	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public char getGender() {
		return gender;
	}
	public void setGender(char gender) {
		this.gender = gender;
	}
	
	
}
