package lab3_7;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class PersonMain2 {

	public static void main(String[] args) {
		
		System.out.println("Person Details");
		System.out.println("----------------------------------");
		
		Person2 person21= new Person2("Pratiksha","Nakti",'F');
		System.out.println("First Name: "+person21.getFirstname());
		System.out.println("Last Name: "+person21.getLastname());
		System.out.println("Gender: "+person21.getGender());
		
		System.out.println("Person Details");
		System.out.println("----------------------------------");
		
		Person2 person22= new Person2("Avishkar","Keni",'M');
		System.out.println("First Name: "+person22.getFirstname());
		System.out.println("Last Name: "+person22.getLastname());
		System.out.println("Gender: "+person22.getGender());
		
		System.out.println("Person Details");
		System.out.println("----------------------------------");
		

		Person2 person23= new Person2("Kunal","Khemu",'M');
		System.out.println("First Name: "+person23.getFirstname());
		System.out.println("Last Name: "+person23.getLastname());
		System.out.println("Gender: "+person23.getGender());

		DateTimeFormatter formatter= DateTimeFormatter.ofPattern("dd-MM-yyyy");  
		String dt="21-03-1990";
		LocalDate dob= LocalDate.parse(dt, formatter);
		
		person23.setDob(dob);
		int age= person23.calcAge(dob);
		System.out.println("----------------------------------");
		System.out.println("First Name: "+person23.getFirstname());
		System.out.println("Last Name: "+person23.getLastname());
		System.out.println("Gender: "+person23.getGender());
		System.out.println("DOB of"+person23.getFirstname()+" is :"+person23.getDob());
		System.out.println("Age is: "+age);

		String fullNm= person23.getFullname("Kunal", "Khemu");
		System.out.println("Full Name :"+fullNm);
	}

}
