package lab3_7;

import java.time.LocalDate;
import java.time.Period;




public class Person2 {

	String firstname;
	String lastname;
	char gender;
	
	LocalDate dob;
	
	
	


	public LocalDate getDob() {
		return dob;
	}


	public void setDob(LocalDate dob) {
		this.dob = dob;
	}


	public Person2() {
		super();
	}
	
	
	public Person2(String firstname, String lastname, char gender) {
		super();
		this.firstname = firstname;
		this.lastname = lastname;
		this.gender = gender;
	}


	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public char getGender() {
		return gender;
	}
	public void setGender(char gender) {
		this.gender = gender;
	}
	
	
	public int calcAge(LocalDate dob){
		
		LocalDate thisDate= LocalDate.now();
		Period prd= dob.until(thisDate);
		int age_yr= prd.getYears();
		return age_yr;
	}
	
	public String getFullname(String fnm, String lnm){
		String fullName= fnm+" "+lnm;
		return fullName;
	}
}
