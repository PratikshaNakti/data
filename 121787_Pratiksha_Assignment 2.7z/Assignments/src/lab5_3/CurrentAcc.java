package lab5_3;

public class CurrentAcc extends Account {
	private double minBalance=1000;
	protected double overDraft= 25000;
	private long accNum;
	private double balance;
	
	
	public CurrentAcc(double balance) {
		super(balance);
		this.balance = balance;
	}
	
/*
	public void withdraw(double amt){
		if((balance-amt<=0)&&(amt<=overDraft)){
		System.out.println("Eligible to overdraft");
		}
		else{
			System.out.println("Not Eligible to overdraft");
		}
		
	}*/
	
	@Override
	public void withdraw(double amt){
		if(balance-amt>=minBalance){
		balance=balance-amt;
		}
		else if((balance-amt<=0)&&(amt<=overDraft)){
			System.out.println("Eligible to overdraft");
			}
			else{
				System.out.println("Not Eligible to overdraft");
			}
		
	}
	
	@Override
	public double getBalance()
	{
		return balance;
	}
	
	@Override
	public String toString() {
		return "Account [accNum=" + accNum + ", balance=" + balance
				+ ", accHolder=" + accHolder + "]";
	}
	
	

}
