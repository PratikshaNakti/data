package LAB_12_SampleBean;

import org.apache.log4j.Logger;

public class Message {
	public static final Logger myLogger= 
			Logger.getLogger(Message.class);
	
	private String msg;
	public void setMessage(String msg) {
	this.msg = msg;
	
	myLogger.info(msg);
	myLogger.debug(msg);
	myLogger.fatal(msg);
	myLogger.warn(msg);
	myLogger.error(msg);

	
	
	}
	public String getMessage() {
	//log messages for each priority level
	
		myLogger.info(msg);
		myLogger.debug(msg);
		myLogger.fatal(msg);
		myLogger.warn(msg);
		myLogger.error(msg);
	return msg;
	}
	}


