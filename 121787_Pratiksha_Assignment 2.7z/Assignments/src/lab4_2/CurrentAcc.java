package lab4_2;

public class CurrentAcc extends Account {
	protected double overDraft= 25000;
	private long accNum;
	private double balance;
	
	
	public CurrentAcc(double balance) {
		super(balance);
		this.balance = balance;
	}
	
/*
	public void withdraw(double amt){
		if((balance-amt<=0)&&(amt<=overDraft)){
		System.out.println("Eligible to overdraft");
		}
		else{
			System.out.println("Not Eligible to overdraft");
		}
		
	}*/
	
	public boolean  withdrawl(double amt){
		System.out.println("OverDraft limit is: "+overDraft);
		if((balance-amt<=0)&&(amt<=overDraft)){
		System.out.println("Eligible to overdraft");
		return true;
		
		}
		else{
			System.out.println("Not Eligible to overdraft");
			return false;
		}
		
	}
	
	

}
