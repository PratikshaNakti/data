package lab4_2;

import java.util.Scanner;

public class Test {

	public static void main(String[] args) {
		
		Scanner sc= new Scanner(System.in);
		Person smith= new Person("Smith", 23);
		Person kathy= new Person("Kathy", 24);
		Person leila= new Person("Leila", 24);
		Person raj= new Person("Raj", 26);
		
		Account smithAcnt= new Account(2000);
		smithAcnt.setAccHolder(smith);
		
		Account kathyAcnt= new Account(3000);
		kathyAcnt.setAccHolder(kathy);
		
		Account leilaAcnt= new SavingsAcc(3000);
		leilaAcnt.setAccHolder(leila);
		
		Account rajAcnt= new CurrentAcc(7000);
		rajAcnt.setAccHolder(raj);
		
		smithAcnt.deposit(2000);
		kathyAcnt.withdraw(1000);
		leilaAcnt.deposit(2000);
		
		System.out.println("Updated balance for Smith:"+smithAcnt.getBalance());
		System.out.println("Updated balance for Kathy:"+kathyAcnt.getBalance());
		System.out.println("Updated balance for Leila:"+leilaAcnt.getBalance());

		
		System.out.println(smithAcnt);
		System.out.println(kathyAcnt);
		System.out.println(leilaAcnt);
		System.out.println(rajAcnt);
		
		leilaAcnt.withdraw(4500);
		System.out.println("Updated balance for Leila:"+leilaAcnt.getBalance());

		System.out.println();
		System.out.println("Enter withdraw amt (Overdraft)");
		double ovr_amt= sc.nextDouble();
		boolean flag= rajAcnt.withdrawl(ovr_amt);
		System.out.println("Overdraft withdrawl permission status :"+flag);
		
		
	}

}

