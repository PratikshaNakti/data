package lab4_2;

public class SavingsAcc extends Account {
	private double minBalance=1000;
	private long accNum;
	private double balance;
	
	

	public SavingsAcc(double balance) {
		super(balance);
		this.balance= balance;
	}


	public void withdraw(double amt){
		if(balance-amt>=minBalance){
		balance= balance-amt;
		}
		else{
			System.out.println("Insufficient balance ");
		}
		
	}
	

}
