package lab6_2;

public class Account {
	protected long accNum;
	protected double balance;
	
	protected Person accHolder;
	static int count=1001;
	
	public void deposit(double amt){
		balance= balance+amt;
		
	}
	
	public void withdraw(double amt){
	
		balance= balance-amt;
		
	}
	
	public double getBalance()
	{
		return balance;
	}

	public long getAccNum() {
		return accNum;
	}

	/*public void setAccNum(long accNum) {
		this.accNum = accNum;
	}*/

	public Person getAccHolder() {
		return accHolder;
	}

	public void setAccHolder(Person accHolder) {
		this.accHolder = accHolder;
	}

	

/*	public void setBalance(double balance) {
		this.balance = balance;
	}*/
	
	
	public Account(double balance) {
		super();
		count++;
		this.accNum = count;
		this.balance = balance;
	}

public Account() {
	super();
	count++;
}

@Override
public String toString() {
	return "Account [accNum=" + accNum + ", balance=" + balance
			+ ", accHolder=" + accHolder + "]";
}

public boolean withdrawl(double d) {
	return false;
	
}
	
	
	

}
