package lab6_2;

public class AgeException extends Exception {

}
