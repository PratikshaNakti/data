package lab6_2;

import java.util.Scanner;

public class Test {

	public static void main(String[] args) {
		
		
		Scanner sc= new Scanner(System.in);
	
		
		try{
		System.out.println("Enter name");
		String nm= sc.nextLine();
		System.out.println("Enter age");
		int age= sc.nextInt();
		Person smith= new Person();
		smith.setAge(age);
		smith.setName(nm);
		
		Account smithAcnt= new SavingsAcc(2000);
		smithAcnt.setAccHolder(smith);
		
		System.out.println(smithAcnt);
		}
		catch(AgeException e){
			System.out.println("Age is not valid. It should be above 15");
		}
		
		
	}

}

