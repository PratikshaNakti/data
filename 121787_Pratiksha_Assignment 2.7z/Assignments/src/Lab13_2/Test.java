package Lab13_2;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyTimer timer=new MyTimer();
		Thread thread=new Thread(timer);
		thread.start();
	}

}
