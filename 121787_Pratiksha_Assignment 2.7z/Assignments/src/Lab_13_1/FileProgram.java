package Lab_13_1;

import java.io.*;

public class FileProgram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			FileInputStream fin= new FileInputStream("D:\\pnakti_demo\\files\\threadSource.txt");
			FileOutputStream fout= new FileOutputStream("D:\\pnakti_demo\\files\\threadTarget.txt");   
		
			Thread t1= new CopyDataThread(fin, fout);
			t1.start();
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		

	}

}
