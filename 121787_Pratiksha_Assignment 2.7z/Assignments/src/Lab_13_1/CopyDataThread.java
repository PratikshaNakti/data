package Lab_13_1;

import java.io.*;

public class CopyDataThread extends Thread{
	
	FileInputStream in;
	FileOutputStream out;
	
	public CopyDataThread(FileInputStream fin, FileOutputStream fout){
	
		/*try {
			in = new FileReader("D:\\pnakti_demo\\files\\threadSource.txt");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			out = new FileWriter("D:\\pnakti_demo\\files\\threadTarget.txt");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}   
		*/
		
		in= fin;
		out= fout;
		
	}
	public void run(){
		
		int ch;
		try {
			int i=1;
			ch = in.read();
			while(ch!= -1){
				out.write((char)ch);
				i++;
				if(i==10){
					System.out.println("10 characters copied");
					try {
						Thread.sleep(5000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					i=1;
				}
				
				ch = in.read();
				
			}
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
	}

}
