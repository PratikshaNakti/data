package lab4_1;

public class Test {

	public static void main(String[] args) {
		Person smith= new Person("Smith", 23);
		Person kathy= new Person("Kathy", 24);
		
		Account smithAcnt= new Account(2000);
		smithAcnt.setAccHolder(smith);
		
		Account kathyAcnt= new Account(3000);
		kathyAcnt.setAccHolder(kathy);
		
		smithAcnt.deposit(2000);
		kathyAcnt.withdraw(2000);
		
		System.out.println("Updated balance for Smith:"+smithAcnt.getBalance());
		System.out.println("Updated balance for Kathy:"+kathyAcnt.getBalance());
	
		System.out.println(smithAcnt);
		System.out.println(kathyAcnt);

	}

}

