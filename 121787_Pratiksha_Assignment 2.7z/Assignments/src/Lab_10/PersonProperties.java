package Lab_10;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Properties;

import com.sun.org.apache.xalan.internal.xsltc.trax.OutputSettings;

public class PersonProperties {
	
	public static void writeProperties(){
		Properties prop= new Properties();
		OutputStream out= null;
		
		prop.setProperty("Name", "Manali Kedar Pednekar");
		prop.setProperty("Gender", "Female");
		prop.setProperty("Country", "India");
		prop.setProperty("DOB", "21-JAN-1990");
		prop.setProperty("Designation", "HR Lead");
		
		try {
			out= new FileOutputStream("D:\\pnakti_demo\\files\\PersonProps.properties");
			try {
				prop.store(out, null);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  
		
		finally{
			try {
				out.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		System.out.println("Successful write");
		System.out.println();
		
	}
	
	public static void readProperties(){
		Properties prop= new Properties();
		InputStream in= null;
		
		try {
			in= new FileInputStream("D:\\pnakti_demo\\files\\PersonProps.properties");
			try {
				prop.load(in);
			}
			catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			System.out.println("Printinng Propertie object: ");
			System.out.println(prop);
			System.out.println();

			System.out.println("Reading properties file :");
			System.out.println("Person Name : "+prop.getProperty("Name"));
			System.out.println("Person Gender : "+prop.getProperty("Gender"));
			System.out.println("Person Country : "+prop.getProperty("Country"));
			System.out.println("Person DOB : "+prop.getProperty("DOB"));
			System.out.println("Person Designation : "+prop.getProperty("Designation"));
			
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			if(in != null){
				try {
					in.close();
				} catch (IOException e) {
					
					e.printStackTrace();
				}
			}
		}
		
		
			
		
		
	}
	
	public static void main(String args[]){
		writeProperties();
		readProperties();
		
	}
	
	
	
	
	

}
