package lab2_4;
import java.util.*;
public class lab2_4 {

	public static void main(String[] args) {
		Person3 person31= new Person3("Anamika","Jain",'F');
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter phone number ");
		String pno= sc.next();
		
		
		person31.setPhone(pno);
		person31.show();
		
		
	}

}
