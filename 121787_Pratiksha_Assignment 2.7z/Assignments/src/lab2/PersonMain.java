package lab2;

class Person{
	String firstname;
	String lastname;
	char gender;
	
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public char getGender() {
		return gender;
	}
	public void setGender(char gender) {
		this.gender = gender;
	}
	
	
}

public class PersonMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person person1= new Person();
		person1.setFirstname("Divya");
		person1.setLastname("Bharathi");
		person1.setGender('F');
		
		System.out.println("Person Details (Counstuctor)");
		System.out.println("--------------------------------------");
		
		System.out.println("First Name : "+person1.getFirstname());
		System.out.println("Last Name : "+person1.getLastname());
		System.out.println("Gender : "+person1.getGender());
	
		

	}

}
