package lab2;

public class lab2_2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int len= args.length;
		int i;
		for(i=0; i<len; i++){
			if(Integer.parseInt(args[i])>0){
				System.out.println("The number is positive "+args[i]);
			}
			else{
				System.out.println("The number is negative "+args[i]);
			}
		}

	}

}
