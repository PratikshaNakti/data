package com.cg.eis.bean;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.eis.Exception.EmployeeException;

public class TestEmployee {
	Employee emp1;

	@Before
	public void setUp() throws Exception {
		emp1= new Employee("311","Vipul",25000,"Programmer");
		
	}

	@After
	public void tearDown() throws Exception {
		emp1= null;
	}
	
	@Test
	public void testgetInsaurance_Sch(){
		emp1.setInsaurance_Sch(25000,"Programmer");
		System.out.println("Checking Insaurance scheme");
		assertEquals("Scheme B", emp1.getInsaurance_Sch());
		
	}
	
	@Test (expected=EmployeeException.class)
	public void testNull() throws EmployeeException{
		System.out.println("from Employee testing exceptions");
		
			Employee emp2= new Employee("318","Kajal",200,"Programmer");
		
		
	}
	
	
	

	

}
