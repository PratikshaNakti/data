package com.cg.eis.bean;

import com.cg.eis.Exception.EmployeeException;

public class Employee {
	private String id;
	private String name;
	private double salary;
	
	private String desg;
	String insaurance_Sch;
	
	public Employee(String id, String name, double salary, String desg) throws EmployeeException {
		super();
		this.id = id;
		this.name = name;
		if(salary>3000){
		this.salary = salary;
		}
		else{
			throw new EmployeeException("Salary invalid. It should be greater than 3000");
		}
		this.desg = desg;
	}
	
	

	public Employee() {
		super();
	}



	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public String getDesg() {
		return desg;
	}

	public void setDesg(String desg) {
		this.desg = desg;
	}

	public String getInsaurance_Sch() {
		return insaurance_Sch;
	}

	/*public void setInsaurance_Sch(String insaurance_Sch) {
		this.insaurance_Sch = insaurance_Sch;
	}*/

     public String setInsaurance_Sch(double salary, String desg ){
		if((salary>5000) && (salary<20000) && (desg.equals("System Associate") )){
			this.insaurance_Sch ="Scheme C";
		}
		else if((salary>=20000) && (salary<40000) && (desg.equals("Programmer") )){
			this.insaurance_Sch ="Scheme B";
		}
		
		else if((salary>=40000) && (desg.equals("Manager") )){
			this.insaurance_Sch ="Scheme A";
		}
		
		else if((salary<5000)&& (desg.equals("Clerk"))){
			this.insaurance_Sch ="No Scheme";
		}
		return this.insaurance_Sch;
		
	}


	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", salary=" + salary
				+ ", desg=" + desg + ", insaurance_Sch=" + insaurance_Sch + "]";
	}
	
	
	
	

}
