import org.junit.*;
import org.junit.Test;
import static org.junit.Assert.*;

public class PersonTest {
	
	

	/*@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() {
		
	}*/
	
	
	@Test
	public void testGetFullName()
	{
		System.out.println("from TestPerson");
		Person per = new Person("Robert","King");
		assertEquals("Robert King",per.getFullName());
		}
	
		@Test (expected=IllegalArgumentException.class)
		public void testNullsInName()
		{
		System.out.println("from TestPerson testing exceptions");
		Person per1 = new Person(null,null);
		}
		
}
