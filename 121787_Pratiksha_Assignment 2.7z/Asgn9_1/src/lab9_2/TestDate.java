package lab9_2;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class TestDate {

	@Test
	public void testReturn(){
		System.out.println("From testReturn");
		Date td= new Date(23, 2, 2017);
		assertEquals("Date is:23/2/2017", td.toString());
		
		assertNotNull(td);
		
	}
	
	@Test
	public void testgetDay(){
		System.out.println("From testGetDay");
		Date td= new Date(23, 2, 2017);
		assertEquals(23, td.getDay());
		
	}
	
	@Test
	public void testgetMonth(){
		System.out.println("From testgetMonth");
		Date td= new Date(23, 2, 2017);
		assertEquals(2, td.getMonth());
		
	}
	
	@Test
	public void testgetYear(){
		System.out.println("From testgetYear");
		Date td= new Date(23, 2, 2017);
		assertEquals(2017, td.getYear());
		
	}
	
	
	

}
