package lab9_2_1;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class TestPerson2 {
	Person2 pr1;
	
	@Before
	public void setUp() throws Exception {
		 pr1= new Person2("Pratiksha","Nakti",'F');
	}

	@After
	public void tearDown() throws Exception {
		pr1= null;
	}

	
	@Test
	public void testgetFirstname(){
		System.out.println("From testgetFirstname");
			assertEquals("Pratiksha", pr1.getFirstname());
		
	}
	
	@Test
	public void testgeLastname(){
		System.out.println("From testgetLasttname");
			assertEquals("Nakti", pr1.getLastname());
		
	}
	@Test
	public void testgetGender(){
		System.out.println("From testgetGender");
			assertEquals('F', pr1.getGender());
		
	}
	
	@Test
	public void nullCheck(){
		System.out.println("NullCheck");
		Person2 pr2= null;
		assertNotNull(pr1);
		assertNull(pr2);
	}
	
	@Test
	public void testdisplayDetails(){
		System.out.println("From testdisplayDetails");
		System.out.println(pr1.displayDetails());
		assertEquals("Person Detail: Pratiksha Nakti F", pr1.displayDetails());
	}
	
}
