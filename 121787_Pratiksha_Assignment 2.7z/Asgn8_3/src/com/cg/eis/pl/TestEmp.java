package com.cg.eis.pl;
import java.util.*;

import com.cg.eis.bean.Employee;
import com.cg.eis.service.EmpServiceImpl;
public class TestEmp {

	public static void main(String[] args) {

		EmpServiceImpl empSr= new EmpServiceImpl();
		empSr.inputEmployee();
		empSr.findScheme();
		//empSr.displayDetail();
		
		empSr.writeObj();
		empSr.readObj();

		
		
	}

}
