package com.cg.eis.service;
import java.util.*;

import com.cg.eis.Exception.EmployeeException;
import com.cg.eis.bean.Employee;

public class EmpServiceImpl implements IEmployeeService {
	Employee e;

	public void inputEmployee() {
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter ID");
		String id= sc.nextLine();
		System.out.println("Enter Name");
		String nm= sc.nextLine();
		System.out.println("Enter designation");
		String desg = sc.nextLine();
		System.out.println("Enter salary");
		double sal= sc.nextDouble();
		
		
		
		try {
			e= new Employee(id, nm, sal, desg);
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}


	public void findScheme() {
		String insSch= null;
		double salary= e.getSalary();
		String desg= e.getDesg();
		
		if((salary>5000) && (salary<20000) && (desg.equals("System Associate") )){
			insSch ="Scheme C";
		}
		else if((salary>=20000) && (salary<40000) && (desg.equals("Programmer") )){
			insSch ="Scheme B";
		}
		
		else if((salary>=40000) && (desg.equals("Manager") )){
			insSch="Scheme A";
		}
		
		else if((salary<5000)&& (desg.equals("Clerk"))){
			insSch="No Scheme";
		}
		
		e.setInsaurance_Sch(insSch);
		
	}


	public void displayDetail() {
		System.out.println(e);
		
	}
	
	

}
