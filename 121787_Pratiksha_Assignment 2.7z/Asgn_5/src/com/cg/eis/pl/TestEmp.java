package com.cg.eis.pl;
import java.util.*;

import com.cg.eis.bean.Employee;
import com.cg.eis.service.EmpServiceImpl;
public class TestEmp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	/*
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter Id, Name, Designation, Salary :");
		String id= sc.nextLine();
		String nm= sc.nextLine();
		String desg= sc.nextLine();
		double sal= sc.nextDouble();
		
		
		Employee emp1= new Employee(id,nm, sal, desg);
		emp1.setInsaurance_Sch(sal, desg);
		
		System.out.println(emp1);
		
		
		System.out.println("Enter Id, Name, Designation, Salary :");
		String id2= sc.nextLine();
		String nm2= sc.nextLine();
		String desg2= sc.nextLine();
		double sal2= sc.nextDouble();
		
		
		Employee emp2= new Employee(id2,nm2, sal2, desg2);
		emp2.setInsaurance_Sch(sal2, desg2);
		
		System.out.println(emp2);*/
		
		EmpServiceImpl empSr= new EmpServiceImpl();
		empSr.inputEmployee();
		empSr.findScheme();
		empSr.displayDetail();
		

		
		
	}

}
