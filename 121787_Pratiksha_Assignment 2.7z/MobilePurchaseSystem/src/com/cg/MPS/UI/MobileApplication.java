package com.cg.MPS.UI;

///import java.util.*;
import java.util.List;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.MPS.Exception.MobileException;
import com.cg.MPS.dto.Mobile;
import com.cg.MPS.service.IMobileService;

import com.cg.MPS.service.MobileServiceImpl;

import com.cg.MPS.util.JdbcUtil;

import java.sql.*;

public class MobileApplication {

	private static final Logger mylogger=
			Logger.getLogger(MobileApplication.class);
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Date purchs_dt;
		 java.util.Date dt= new java.util.Date();
		 long time= dt.getTime();
		 purchs_dt= new Date(time);

	
		 mylogger.info("Application started successfully..");
		Scanner sc = new Scanner(System.in);
		Scanner sc2 = new Scanner(System.in);
		IMobileService moblImpl = new MobileServiceImpl();
	

		int ch;
		boolean res_nm;
		boolean res_mail;
		boolean res_ph;
		boolean res_id;
		String cus_name;
		String cus_ph;
		String cus_mail;
		String purc_mid;
		int ins_mid;

		do{ 
			
			printDetail();
		System.out.println("Select number of your choice");
		
		

		ch = sc.nextInt();

		switch (ch) {

		case 1:
			try {
				List<Mobile> mList = moblImpl.showAllMobiles();
				System.out.println("Showing all the available mobiles: ");
				for (Mobile m : mList) {
					System.out.println(m);
				}
				System.out.println();

			} catch (MobileException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("Show error");
			}

			break;

		case 2:
			System.out.println("Enter a mobile Id to delete :");
			String id = sc.next();
			int mid = Integer.parseInt(id);
			Pattern pattern= Pattern.compile("[0-9]{4}");
			Matcher matcher = pattern.matcher(id);		
			boolean res= matcher.matches();
			
			if( res==true){
			
		

			try {
				boolean flag = moblImpl.deleteMbl(mid);
				System.out.println("Delete status: " + flag);
				if(flag== true){
					System.out.println("Delete successful for mobile: "+mid);
				}
				

			} catch (MobileException e) {
				// TODO Auto-generated catch block
				e.printStackTrace(); 
			
			}
			
			}
			else{
				System.out.println("Mobile Id should be 4 digit numeric ");
			}
			break;
			
			
		case 3:
			System.out.println("Enter minimum price range:");
			int min_p = sc.nextInt();
			System.out.println("Enter maximum price range:");
			int max_p = sc.nextInt();
			System.out.println("Showing the  mobiles of your price range: ");
			
			List<Mobile> mList2;
			try {
				mList2 = moblImpl.searchMobile(min_p, max_p);
				
				for(Mobile m: mList2){
					System.out.println(m);
				}
				
				
			} catch (MobileException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("Search on range error");
			}
			
			
			System.out.println();
			break;
			
		case 4:
			//name validatn
			do{
			System.out.println("Enter Customer name");
			 cus_name= sc2.nextLine();
			
			Pattern pattern2= Pattern.compile("^[A-Z]{1}[a-zA-Z\\s]{1,19}");
			Matcher matcher2 = pattern2.matcher(cus_name);		
			 res_nm= matcher2.matches();
			if(res_nm== false){
				System.out.println("Name is not valid. Please enter valid one");
			}
		} while(res_nm== false);
			
			//mail validation
			do{
			System.out.println("Enter Customer Mail Id");
			 cus_mail=  sc2.nextLine();
			
			Pattern pattern3= Pattern.compile("^(.+)@(.+)$");
			Matcher matcher3 = pattern3.matcher(cus_mail);		
			 res_mail= matcher3.matches();
			if(res_mail== false){
				System.out.println("Mail is not valid. Please enter valid one");
			}
			}while(res_mail!=true);
			
			//phone
			do{
			System.out.println("Enter Customer Phone no");
			cus_ph= sc2.nextLine();
			Pattern pattern4= Pattern.compile("^[7|8|9][0-9]{9}");
			Matcher matcher4 = pattern4.matcher(cus_ph);		
			res_ph= matcher4.matches();
			if(res_ph== false){
				System.out.println("Phone no is not valid. Please enter valid one");
			}
			}while(res_ph!=true);
			
			
			//taking mob id
			do{
			System.out.println("Enter mobile ID:");
			 purc_mid = sc2.nextLine();
			 ins_mid= Integer.parseInt(purc_mid);
			
			Pattern pattern5= Pattern.compile("[0-9]{4}");
			Matcher matcher5 = pattern5.matcher(purc_mid);		
			res_id= matcher5.matches();
			if(res_id== false){
				System.out.println("Mobile id is not valid. Please enter valid one");
			}
			}while(res_id!= true);
			
			if((res_nm==true) && (res_mail==true) && (res_ph==true) && (res_id==true)){
			
			try {
				boolean res_ins= moblImpl.insertPurchaseDetails(cus_name, cus_mail, cus_ph, purchs_dt, ins_mid);
				System.out.println("Status of inserting purchase detail: "+res_ins);
				if(res_ins== true){
					System.out.println("Insertion done successfully for Customer: "+cus_name);
				}
			} catch (MobileException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("Insert purchase detail error"); 
			}
			try {
				boolean res_upd = moblImpl.updateQuantity(ins_mid); 
				System.out.println("Status of updating quantiy: "+res_upd);
				if(res_upd== true){
					System.out.println("Quantity updated successfully.");
				}
			} catch (MobileException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("Update quantity  error");
			}
			
			}
			
			break;
			
		case 5:
			//Exit
			System.exit(0);
			break;
			
			default:
				System.out.println("Choice number is wrong");

		}
		
	} while(ch!=5);
	}
		
		public static void printDetail(){
			System.out.println("**********");
			System.out.println("1. Show All Mobiles");
			System.out.println("2. Delete A Mobile");
			System.out.println("3. Search a mobile on price range");
			System.out.println("4. Update Purchase Details");
			System.out.println("5. Exit");
			System.out.println("***********");
		}

	
}
