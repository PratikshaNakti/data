package com.cg.MPS.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.MPS.Exception.MobileException;
import com.cg.MPS.UI.MobileApplication;
import com.cg.MPS.dto.Mobile;
import com.cg.MPS.dto.PurchaseDetails;
import com.cg.MPS.util.JdbcUtil;

public class MobileDaoImpl implements IMobileDao {
	
	private static final Logger mylogger=
			Logger.getLogger(MobileDaoImpl.class);
	
	

	Connection con;
	PreparedStatement psmt;
	

	@Override
	public List<Mobile> showMobiles() throws MobileException {
		 PropertyConfigurator.configure("log4j.properties");
		
		con = JdbcUtil.getConnection();

		List<Mobile> mList = new ArrayList<Mobile>();

		String qry = "SELECT * FROM mobiles";
		try {
			psmt = con.prepareStatement(qry);
			ResultSet rs = psmt.executeQuery();

			while (rs.next()) {
				int m_id = rs.getInt(1);
				String m_nm = rs.getString("name");
				double m_price = rs.getInt("price");
				int m_qty = rs.getInt("quantity");

				Mobile m = new Mobile();
				m.setMobileid(m_id);
				m.setMobileName(m_nm);
				m.setPrice(m_price);
				m.setQuantity(m_qty);

				mList.add(m);

			}
			mylogger.info("Displayed all mobiles");

		} catch (SQLException e) {

			e.printStackTrace();
			throw new MobileException("Data not found");

		} finally {
			try {
				con.close();
			} catch (SQLException e) {

				e.printStackTrace();
			}
		}

		return mList;
	}

	@Override
	public boolean deleteMobile(int mobileid) throws MobileException {
		 PropertyConfigurator.configure("log4j.properties");
		con = JdbcUtil.getConnection();
		int rec = 0;
		String dlttQry = "DELETE FROM mobiles WHERE mobileid=?";
		try {
			psmt = con.prepareStatement(dlttQry);
			psmt.setInt(1, mobileid);
			rec = psmt.executeUpdate();

			if (rec > 0) {
				mylogger.info(rec+" rows deleted");
				return true;
				
				
			} 
			else {
				mylogger.info("Failed to delete");
				throw new MobileException(
						"Failed to delete. Please enter existing mobile ID.");
			}

		} catch (SQLException e) {

			e.printStackTrace();
			throw new MobileException("Data not deleted");

		} finally {
			try {
				con.close();
			} catch (SQLException e) {

				e.printStackTrace();
			}
		}

		//return false;
	}

	@Override
	public List<Mobile> searchByPrice(int min, int max) throws MobileException {

		List<Mobile> mList = new ArrayList<Mobile>();
		con = JdbcUtil.getConnection();
		String searchQry = "SELECT * FROM mobiles WHERE price>=? AND price<=?";
		try {
			psmt = con.prepareStatement(searchQry);
			psmt.setInt(1, min);
			psmt.setInt(2, max);

			ResultSet rs = psmt.executeQuery();

			while (rs.next()) {
				int m_id = rs.getInt(1);
				String m_nm = rs.getString("name");
				double m_price = rs.getInt("price");
				int m_qty = rs.getInt("quantity");

				Mobile m = new Mobile();
				m.setMobileid(m_id);
				m.setMobileName(m_nm);
				m.setPrice(m_price);
				m.setQuantity(m_qty);

				mList.add(m);

			}
			mylogger.info("Displayed all mobiles within your price range");

		} catch (SQLException e) {

			e.printStackTrace();
			throw new MobileException("Data not found");
		} finally {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return mList;
	}
	
	
	
	
	@Override
	public boolean insertPurchaseDetails(String cust_name, String cust_mail,
			String cust_phone, java.sql.Date pch_dt, int mobileid) throws MobileException {
		

		PreparedStatement psmt3;
		PreparedStatement psmt2;
		con= JdbcUtil.getConnection();
		int rec=0;
		int qt=0;
		String insQry= "INSERT INTO purchasedetails VALUES(purchase_seq.NEXTVAL,?,?,?,?,?)";
		
		String qry1= "SELECT quantity FROM mobiles WHERE mobileid=?"; 
		
		
		try {
			
			psmt2= con.prepareStatement(qry1);
			psmt2.setInt(1, mobileid);
			ResultSet rs = psmt2.executeQuery();
			while(rs.next()){
				 qt= rs.getInt(1);
				System.out.println(" Existing Quantity :"+qt);
			}
			
			if(qt>0){
				
			
			psmt3= con.prepareStatement(insQry);
			//psmt.setInt(1, );
			psmt3.setString(1, cust_name);
			psmt3.setString(2, cust_mail);
			psmt3.setString(3, cust_phone);
			//psmt.setDate(4, (java.sql.Date) purchaseDate);
			psmt3.setDate(4, pch_dt);
			psmt3.setInt(5, mobileid);
			
			rec= psmt3.executeUpdate();
			
			PurchaseDetails pd;
			 pd= new PurchaseDetails();
				pd.setCname(cust_name);
				pd.setMailid(cust_mail);
				pd.setPhoneno(cust_phone);
				pd.setPurchasedate(pch_dt);
				pd.setMobileid(mobileid);
				
				System.out.println(pd.toString());

			if(rec>0){
				mylogger.info("Record inserted successfully");
				return true;
		
			}
			
		}

			
			else
			{
				mylogger.error("Purchase is not applicable");
				throw new MobileException("Mobile quantity is 0. Purchase is not applicable");

			}
			
		} 
		
		
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		
			throw new MobileException("Purchase details failed to update");
		}
		finally
		{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return false;
	}
	
	
	

	@Override
	public boolean updateQuantity(int mobileid)
			throws MobileException {

		PreparedStatement psmt3;
		PreparedStatement psmt2;
		con= JdbcUtil.getConnection();
		int rec=0;
		
		int qt=0;
		
		String qry1= "SELECT quantity FROM mobiles WHERE mobileid=?"; 
		String updtQry= "UPDATE mobiles SET quantity=? WHERE mobileid=?";
	
		try {
			
			
			psmt2= con.prepareStatement(qry1);
			psmt2.setInt(1, mobileid);
			ResultSet rs = psmt2.executeQuery();
			while(rs.next()){
				 qt= rs.getInt(1);
			
			}
			int newQnty= qt-1;
			
			psmt= con.prepareStatement(updtQry);
			psmt.setInt(1, newQnty);
			psmt.setInt(2, mobileid);
			rec= psmt.executeUpdate();
			
			if(rec>0){
				mylogger.info("Quantity updated successfully");
				return true;
			
			}
			
		} catch (SQLException e) {
			
			e.printStackTrace();
			mylogger.info("Quantity updation failed");
			throw new MobileException("Data is not updated");
		}
		finally{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return false;
	}


	
	

}
