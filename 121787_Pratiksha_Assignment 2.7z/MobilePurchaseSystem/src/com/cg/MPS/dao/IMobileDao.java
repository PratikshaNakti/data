package com.cg.MPS.dao;

import java.sql.Date;
import java.util.*;

import com.cg.MPS.Exception.MobileException;
import com.cg.MPS.dto.Mobile;

public interface IMobileDao {
	
	List<Mobile> showMobiles() throws MobileException;
	boolean deleteMobile(int mobileid) throws MobileException;
	List<Mobile> searchByPrice(int min, int max) throws MobileException;

	boolean insertPurchaseDetails(String cust_name, String cust_mail, String cust_phone,  Date pch_dt, int mobileid) throws MobileException;  
	boolean updateQuantity(int mobileid) throws MobileException; 

}
