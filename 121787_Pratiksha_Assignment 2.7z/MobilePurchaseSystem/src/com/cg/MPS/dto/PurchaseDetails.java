package com.cg.MPS.dto;

import java.sql.Date;

//import java.util.Date;

public class PurchaseDetails {

	private int purchaseid;
	private String cname;
	private String mailid;
	private String phoneno;
	private Date purchasedate;
	private int mobileid;
	
	public PurchaseDetails() {
		super();
	}
	
	public PurchaseDetails(int purchaseid, String cname, String mailid,
			String phoneno, Date purchasedate, int mobileid) {
		super();
		this.purchaseid = purchaseid;
		this.cname = cname;
		this.mailid = mailid;
		this.phoneno = phoneno;
		this.purchasedate = purchasedate;
		this.mobileid = mobileid;
	}

	public int getPurchaseid() {
		return purchaseid;
	}

	public void setPurchaseid(int purchaseid) {
		this.purchaseid = purchaseid;
	}

	public String getCname() {
		return cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}

	public String getMailid() {
		return mailid;
	}

	public void setMailid(String mailid) {
		this.mailid = mailid;
	}

	public String getPhoneno() {
		return phoneno;
	}

	public void setPhoneno(String phoneno) {
		this.phoneno = phoneno;
	}

	public Date getPurchasedate() {
		return purchasedate;
	}

	public void setPurchasedate(Date purchasedate) {
		this.purchasedate = purchasedate;
	}

	public int getMobileid() {
		return mobileid;
	}

	public void setMobileid(int mobileid) {
		this.mobileid = mobileid;
	}

	@Override
	public String toString() {
		return "PurchaseDetails [purchaseid=" + purchaseid + ", cname=" + cname
				+ ", mailid=" + mailid + ", phoneno=" + phoneno
				+ ", purchasedate=" + purchasedate + ", mobileid=" + mobileid
				+ "]";
	}
	
	
	
	
}
