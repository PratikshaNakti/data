package com.cg.MPS.junittest;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.MPS.Exception.MobileException;
import com.cg.MPS.dao.IMobileDao;
import com.cg.MPS.dao.MobileDaoImpl;

public class TestMobileDaoImplSearch {
	IMobileDao iMobl;

	@Before
	public void setUp() throws Exception {
		iMobl= new MobileDaoImpl();
	}

	@After
	public void tearDown() throws Exception {
		iMobl= null;
	}

	@Test
	public void testSearchByPrice() {
		try {
			assertNotNull(iMobl.searchByPrice(10000, 20000));
		} catch (MobileException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
