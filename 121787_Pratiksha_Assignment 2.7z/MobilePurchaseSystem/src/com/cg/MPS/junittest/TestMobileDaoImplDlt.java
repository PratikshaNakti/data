package com.cg.MPS.junittest;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.MPS.Exception.MobileException;
import com.cg.MPS.dao.IMobileDao;
import com.cg.MPS.dao.MobileDaoImpl;

public class TestMobileDaoImplDlt {
	IMobileDao iMobl;

	@Before
	public void setUp() throws Exception {
		iMobl= new MobileDaoImpl();
	}

	@After
	public void tearDown() throws Exception {
		iMobl= null;
	}

	@Test
	public void testDeleteMobile() {
		try {
			assertEquals(true, iMobl.deleteMobile(1007));
			//assertNotNull(iMobl.deleteMobile(1002));
		} catch (MobileException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
