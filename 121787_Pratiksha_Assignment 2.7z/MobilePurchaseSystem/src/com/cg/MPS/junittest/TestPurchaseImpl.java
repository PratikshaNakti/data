package com.cg.MPS.junittest;

import static org.junit.Assert.*;


import java.sql.Date;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.MPS.Exception.MobileException;
import com.cg.MPS.dao.IMobileDao;

import com.cg.MPS.dao.MobileDaoImpl;


public class TestPurchaseImpl {
	IMobileDao iMobile;
	boolean res;

	@Before
	public void setUp() throws Exception {
		iMobile= new MobileDaoImpl();
	}

	@After
	public void tearDown() throws Exception {
		iMobile=null;
	}

	@Test
	public void testInsertPurchaseDetails() {
		try {
			 Date purchs_dt;
			 java.util.Date dt= new java.util.Date();
			 long time= dt.getTime();
			 purchs_dt= new Date(time);
		res= iMobile.insertPurchaseDetails("Ravi", "ravi@yahoo.com", "8097564378", purchs_dt, 1008);
		} catch (MobileException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		assertEquals(true, res);
	}

}
