package com.cg.MPS.service;

import java.sql.Date;
import java.util.List;

import com.cg.MPS.Exception.MobileException;
import com.cg.MPS.dto.Mobile;

public interface IMobileService {
	List<Mobile> showAllMobiles() throws MobileException;
	boolean deleteMbl(int mobileid) throws MobileException;
	List<Mobile> searchMobile(int min, int max) throws MobileException;
	//boolean updateQty(int mobileid, int quantity) throws MobileException; 

	boolean insertPurchaseDetails(String cust_name, String cust_mail, String cust_phone,  Date pch_dt, int mobileid) throws MobileException;  
	boolean updateQuantity(int mobileid) throws MobileException; 
}
