package com.cg.MPS.service;

import java.sql.Date;
import java.util.List;

import com.cg.MPS.Exception.MobileException;
import com.cg.MPS.dao.IMobileDao;
import com.cg.MPS.dao.MobileDaoImpl;
import com.cg.MPS.dto.Mobile;

public class MobileServiceImpl implements IMobileService{
	
	IMobileDao imobile= new MobileDaoImpl();

	@Override
	public List<Mobile> showAllMobiles() throws MobileException {
		
		return imobile.showMobiles();
	}

	@Override
	public boolean deleteMbl(int mobileid) throws MobileException {
		
		return imobile.deleteMobile(mobileid);
	}

	@Override
	public List<Mobile> searchMobile(int min, int max) throws MobileException {
		
		return imobile.searchByPrice(min, max);
	}

	/*@Override
	public boolean updateQty(int mobileid, int quantity) throws MobileException {
		
		return imobile.updateQuantity(mobileid, quantity);
	}
	*/


	@Override
	public boolean insertPurchaseDetails(String cust_name, String cust_mail,
			String cust_phone,  Date pch_dt, int mobileid) throws MobileException {
		
		
		
		return imobile.insertPurchaseDetails(cust_name, cust_mail, cust_phone, pch_dt, mobileid);
		
		
	}

	@Override
	public boolean updateQuantity(int mobileid) throws MobileException {
		// TODO Auto-generated method stub
		return imobile.updateQuantity(mobileid);
	}
	
}
