package com.cg.MPS.Exception;

public class MobileException extends Exception{
	
	public MobileException(String msg){
		super(msg);
		
		
	}

}
