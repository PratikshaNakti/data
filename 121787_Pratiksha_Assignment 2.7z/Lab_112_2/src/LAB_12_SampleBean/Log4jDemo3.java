package LAB_12_SampleBean;

import org.apache.log4j.Logger;

public class Log4jDemo3 {

	public static final Logger myLogger= 
			Logger.getLogger(Log4jDemo3.class);
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Message msg= new Message();
		msg.setMessage("Hello..message");
		
		myLogger.debug("Debug message");
		myLogger.info("Info message");
		myLogger.warn("Warn message");
		myLogger.error("Error message");
		myLogger.fatal("Fatal message");
	
		
		
	
		System.out.println(msg.getMessage());
		
	}

}
