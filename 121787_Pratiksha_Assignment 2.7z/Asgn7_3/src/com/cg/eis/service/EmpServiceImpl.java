package com.cg.eis.service;
import java.util.*;

import com.cg.eis.bean.Employee;

public class EmpServiceImpl implements IEmployeeService {
	Scanner sc= new Scanner(System.in);
	 
	HashMap<Integer, Employee> empMap= new HashMap<Integer, Employee>();

	public void inputEmployee() {
		
		
		Employee e1= new Employee("124", "Kevin", 24000, "Programmer");
		e1.setInsaurance_Sch(24000, "Programmer");
		empMap.put(1, e1);
		
		Employee e2= new Employee("125", "Pratiksha", 44000, "Manager");
		e2.setInsaurance_Sch(44000, "Manager");
		empMap.put(2, e2);
		
		Employee e3= new Employee("100", "Amit", 15000, "System Associate");
		e3.setInsaurance_Sch(15000, "System Associate");
		empMap.put(3, e3);
		
		Employee e4= new Employee("130", "Sham", 4000, "Clerk");
		e4.setInsaurance_Sch( 4000, "Clerk");
		empMap.put(4, e4);
		
		Employee e5= new Employee("141", "Karan", 22000, "Programmer");
		e5.setInsaurance_Sch(22000, "Programmer");
		empMap.put(5, e5);
		
		Employee e6= new Employee("142", "Raveena", 44000, "Manager");
		e6.setInsaurance_Sch(44000, "Manager");
		empMap.put(6, e6);
		
		
		Set st= empMap.entrySet();
		Iterator i= st.iterator();
		while (i.hasNext()) {
			Map.Entry me = (Map.Entry) i.next();
			System.out.println(me.getKey() + ": " + me.getValue());
		}
	}
	
	

	
	public void displayOnScheme() {
		
		System.out.println();
		System.out.println("Enter insurance scheme");
		String ins= sc.nextLine();
		
		for(int j=1; j<= empMap.size(); j++){
			String test= empMap.get(j).getInsaurance_Sch();
			if(ins.equals(test)){
				System.out.println(empMap.get(j));
			}
		}

		
		
	}
	
	
	public void deleteEmp(){
		System.out.println();
		System.out.println();
		System.out.println("Enter insurance scheme to delete");
		String ins= sc.nextLine();
		
		for(int j=1; j<= empMap.size(); j++){
			String test= empMap.get(j).getInsaurance_Sch();
			if(ins.equals(test)){
				empMap.remove(j);
			}
		}
		
		
		System.out.println();
		System.out.println();
		System.out.println("After Deleting :");
		Set st= empMap.entrySet();
		Iterator i= st.iterator();
		while (i.hasNext()) {
			Map.Entry me = (Map.Entry) i.next();
			System.out.println(me.getKey() + ": " + me.getValue());
		}
	}
	
	
	
}
