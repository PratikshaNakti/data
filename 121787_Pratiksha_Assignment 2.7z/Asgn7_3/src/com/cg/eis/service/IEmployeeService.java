package com.cg.eis.service;

import com.cg.eis.bean.Employee;

public interface IEmployeeService {
	public void inputEmployee();
	//public void findScheme();
	//public void displayDetail();
	

}
