package com.cg.eis.util;

import java.io.*;
import java.util.Properties;
import java.sql.*;


public class JdbcUtil {
	
	
	public static Properties loadProperty(){
		
		Properties prop= new Properties();
		InputStream in = null;
		
		try {
			in= new FileInputStream("oracle.properties");
		} catch (FileNotFoundException e) {
			
			e.printStackTrace();
		}
		 try {
			prop.load(in);
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		 finally{
			 try {
				in.close();
			} catch (IOException e) {
				
				e.printStackTrace();
			}
		 }
		 return prop;
		 
	  
		
	}
	
	public static Connection getConnection(){
		
		String url, usernm, pass, driver;
		Connection con= null;
		Properties prop= loadProperty();
		
		 driver= prop.getProperty("oracle.driver");
		 url= prop.getProperty("oracle.url");
		 usernm= prop.getProperty("oracle.uname");
		 pass= prop.getProperty("oracle.upass");
		 
		 try {
			Class.forName(driver);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 
		 try {
			con= DriverManager.getConnection(url, usernm, pass);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  
		 return con;
		 

	}
	
	

}
