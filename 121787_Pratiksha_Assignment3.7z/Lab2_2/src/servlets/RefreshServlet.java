package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class RefreshServlet
 */
@WebServlet("/autorefresh")
public class RefreshServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	PrintWriter out= null;

	
	
	@Override
	public void init() throws ServletException {
		// TODO Auto-generated method stub
		
		 
	
	}


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		out= response.getWriter();
		
		out.write("<br>");
		response.addHeader("Refresh", "5;URL=https://ispace.ig.capgemini.com/sitepages/index.aspx");
		 
		out.println("Page Refreshed at : " + new Date());
		out.write("<br>");
		//response.sendRedirect("https://ispace.ig.capgemini.com/sitepages/index.aspx");
		/*out.write("Click the below link for ISpace:");
		out.write("<br>");
		out.write("<a href=https://ispace.ig.capgemini.com/sitepages/index.aspx> ISpace </a>");*/
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
