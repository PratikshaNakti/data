package com.cg.lab2.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/validate")
public class Validate extends HttpServlet {
	private static final long serialVersionUID = 1L;
	PrintWriter out;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		out= response.getWriter();
	
		String userNm= request.getParameter("uname");
		String userPass= request.getParameter("pswd");
		
		if((userNm.equals("admin")) && (userPass.equals("admin"))) {
			System.out.println("Login successful");
			response.sendRedirect("success.html");
		}
		
		else{
			System.out.println("Login Unsuccessful");
			response.sendRedirect("failure.html");
		}
		
		//out.write(request.getLocalName());
		System.out.println("The locale setting: ");
		System.out.println("Locale name:"+request.getLocalName());
		System.out.println(request.getLocale()+" , Locale port:"+ request.getLocalPort()+", Locale address:"+ request.getLocalAddr());
		
		System.out.println("Data transfered in bytes : ");
		System.out.println(request.getContentLength());
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
