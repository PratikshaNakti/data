package com.cg.bill.bean;

import java.sql.Date;

public class BillDetails {

	int billNum;
	int consumerNum;
	int CurntReading;
	int unitConsumed;
	float netAmnt;
	Date billDate;
	public BillDetails() {
	
		
	}
	
	
	public BillDetails(int billNum, int consumerNum, int curntReading,
			int unitConsumed, float netAmnt, Date billDate) {
		super();
		this.billNum = billNum;
		this.consumerNum = consumerNum;
		CurntReading = curntReading;
		this.unitConsumed = unitConsumed;
		this.netAmnt = netAmnt;
		this.billDate = billDate;
	}



	public int getBillNum() {
		return billNum;
	}
	public void setBillNum(int billNum) {
		this.billNum = billNum;
	}
	public int getConsumerNum() {
		return consumerNum;
	}
	public void setConsumerNum(int consumerNum) {
		this.consumerNum = consumerNum;
	}
	public int getCurntReading() {
		return CurntReading;
	}
	public void setCurntReading(int curntReading) {
		CurntReading = curntReading;
	}
	public int getUnitConsumed() {
		return unitConsumed;
	}
	public void setUnitConsumed(int unitConsumed) {
		this.unitConsumed = unitConsumed;
	}
	public float getNetAmnt() {
		return netAmnt;
	}
	public void setNetAmnt(float netAmnt) {
		this.netAmnt = netAmnt;
	}
	public Date getBillDate() {
		return billDate;
	}
	public void setBillDate(Date billDate) {
		this.billDate = billDate;
	}


	@Override
	public String toString() {
		return "BillDetails [billNum=" + billNum + ", consumerNum="
				+ consumerNum + ", CurntReading=" + CurntReading
				+ ", unitConsumed=" + unitConsumed + ", netAmnt=" + netAmnt
				+ ", billDate=" + billDate + "]";
	}

	
	
	
}
