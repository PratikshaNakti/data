package com.cg.bill.dao;

import com.cg.bill.bean.BillDetails;
import com.cg.bill.exceptions.BillException;


public interface IBillDao {

	public int addBillDetail(int cons_num, BillDetails billDetail) throws BillException; 
}
