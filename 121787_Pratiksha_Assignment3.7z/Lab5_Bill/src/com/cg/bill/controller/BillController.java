package com.cg.bill.controller;

import java.io.IOException;
import java.sql.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.bill.bean.BillDetails;
import com.cg.bill.exceptions.BillException;
import com.cg.bill.services.BillServiceImpl;
import com.cg.bill.services.IBillService;


@WebServlet("*.do")
public class BillController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	IBillService billService;
   
    public BillController() {
        super();
        billService= new BillServiceImpl();
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}
	
	private void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path= request.getServletPath();
		System.out.println(path);
		
		if(path.equals("/login.do")){
			String userNm= request.getParameter("uname");
			String userPass= request.getParameter("pswd");
			
			if((userNm.equals("admin")) && (userPass.equals("admin"))) {
				System.out.println("Login successful");
				response.sendRedirect("getData.html");
			}
			
			else{
				System.out.println("Login Unsuccessful");
				response.sendRedirect("failure.html");
			}
			
		}
		
		if(path.equals("/calculate.do")){
			String conNum= request.getParameter("con_num");
			String lRead= request.getParameter("lReading");
			String cRead= request.getParameter("cReading");
			
			int consNum= Integer.parseInt(conNum);
			int lsRead=Integer.parseInt(lRead);
			int crRead=Integer.parseInt(cRead);
			if(crRead<lsRead){
				System.out.println("Currnet reading cannot be less than last reading.");
				request.setAttribute("msg", "Currnet reading cannot be less than last reading.");
				RequestDispatcher disp= request.getRequestDispatcher("getData.html");
				disp.forward(request, response);
			}
			
			int unitCon;
			float netAmt;
			int fix=100;
			
			unitCon= crRead-lsRead;
			netAmt= (float) ((unitCon*1.15)+fix);
			
			java.util.Date d= new java.util.Date();
			long current= d.getTime();
			Date dt= new Date(current);
			
			BillDetails billDet= new BillDetails();
			billDet.setConsumerNum(consNum);
			billDet.setCurntReading(crRead);
			billDet.setUnitConsumed(unitCon);
			billDet.setNetAmnt(netAmt);
			billDet.setBillDate(dt);
			
			try {
				int billId= billService.addBillDetail(consNum, billDet);
				
				System.out.println("Bill ID: "+billId);
				
				request.setAttribute("BillData", billDet);
				RequestDispatcher disp= request.getRequestDispatcher("billSuccess.jsp");
				disp.forward(request, response);
				
			
			} catch (BillException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("Problem at Calculate.do");
				response.sendRedirect("invalid.jsp");
			}
			
		}
		
	}

}
