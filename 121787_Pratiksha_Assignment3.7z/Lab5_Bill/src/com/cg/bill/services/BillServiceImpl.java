package com.cg.bill.services;

import com.cg.bill.bean.BillDetails;
import com.cg.bill.dao.BillDaoImpl;
import com.cg.bill.dao.IBillDao;
import com.cg.bill.exceptions.BillException;

public class BillServiceImpl implements IBillService{

	IBillDao dao;
	public BillServiceImpl() {
		dao = new BillDaoImpl();
	}

	@Override
	public int addBillDetail(int cons_num, BillDetails billDetail) throws BillException {
		
		return dao.addBillDetail(cons_num, billDetail);
	}

}
