package com.cg.bill.services;

import com.cg.bill.bean.BillDetails;
import com.cg.bill.exceptions.BillException;

public interface IBillService {

	public int addBillDetail(int cons_num, BillDetails billDetail) throws BillException; 
}
