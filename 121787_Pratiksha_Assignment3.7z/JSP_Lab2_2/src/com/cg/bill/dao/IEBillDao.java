package com.cg.bill.dao;

import java.util.List;

import com.cg.bill.bean.BillDetails;
import com.cg.bill.bean.Consumers;
import com.cg.bill.exceptions.BillException;

public interface IEBillDao {

	public List<Consumers> showAll() throws BillException;
	
	public Consumers searchCons(int id) throws BillException;
	
	public List<BillDetails> getBill(int conId) throws BillException;
	
	public int addBillDetail(int cons_num, BillDetails billDetail) throws BillException; 
}
