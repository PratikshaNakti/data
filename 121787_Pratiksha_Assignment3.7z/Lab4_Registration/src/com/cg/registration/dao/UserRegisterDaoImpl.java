package com.cg.registration.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;



import java.util.ArrayList;

import com.cg.registration.entities.UserDetails;
import com.cg.registration.exceptions.UserException;
import com.cg.registration.util.DbUtil;
import com.cg.registration.util.JdbcUtil;



public class UserRegisterDaoImpl implements UserRegisterDao {
	//private JndiUtil util;
	//private JdbcUtil util;

	Connection connect= null;
	public UserRegisterDaoImpl() throws UserException {
		//util= new JndiUtil();
		//util= new JdbcUtil();
		
	}

	@Override
	public boolean insertRecord(UserDetails user) throws UserException {
		
		PreparedStatement stmt1= null;
		
		int rec_ins=0;
		
		String fName= user.getFirstName();
		String lName= user.getLastName();
		String pswd= user.getPassword();
		char gender= user.getGender();
		String skillSet= user.getSkills();
		String city= user.getCity();
		
		/*String skillSet= "";
		for(int i=0; i<skill.length; i++){
			String skillIndexValue= skill[i];
			skillSet= skillSet.concat(skillIndexValue+", ");
		}
		
*/		String insQry="INSERT INTO RegisteredUsers (firstname, lastname, password, gender, skillset, city) VALUES (?,?,?,?,?,?)";
		try {
			connect= DbUtil.obtainConnection();
			stmt1= connect.prepareStatement(insQry);
			stmt1.setString(1, fName);
			stmt1.setString(2, lName);
			stmt1.setString(3, pswd);
			stmt1.setString(4, String.valueOf(gender));
			stmt1.setString(5, skillSet);
			stmt1.setString(6, city);
			 rec_ins= stmt1.executeUpdate();
			 
			 if(rec_ins>0){
				 return true;
			 }
			 else{
				 throw new UserException("Record insertion failed.");
			 }
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new UserException("JDBC failed.", e);
		}
		finally{
			try {
				connect.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
	}

	@Override
	public ArrayList<UserDetails> getUserList() throws UserException {
		PreparedStatement stmt2= null;
		connect= DbUtil.obtainConnection();
		
		String show= "SELECT * FROM RegisteredUsers";		
		ArrayList<UserDetails> userList= new ArrayList<UserDetails>();
		
		try {
			stmt2= connect.prepareStatement(show);
			ResultSet rs1= stmt2.executeQuery();
			
			while(rs1.next()){
				String user_fName= rs1.getString(1);
				String user_lName= rs1.getString(2);
				String user_pswd= rs1.getString(3);
				String user_genStr= rs1.getString(4);
				char user_gen= '\u0000';
				if(user_genStr.length()>0){
					 
					user_gen= user_genStr.charAt(0);
				}
				String user_skillSet= rs1.getString(5);
				String user_city= rs1.getString(6);
				
				UserDetails showUser= new UserDetails();
				showUser.setFirstName(user_fName);
				showUser.setLastName(user_lName);
				showUser.setPassword(user_pswd);
				showUser.setGender(user_gen);
				showUser.setSkills(user_skillSet);
				showUser.setCity(user_city);
				
				userList.add(showUser);
				
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new UserException("No data found(dao)");
		}
		finally{
			try {
				connect.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return userList;
	}

}
