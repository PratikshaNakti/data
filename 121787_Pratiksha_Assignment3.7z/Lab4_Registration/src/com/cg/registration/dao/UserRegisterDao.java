package com.cg.registration.dao;



import java.util.ArrayList;

import com.cg.registration.entities.UserDetails;
import com.cg.registration.exceptions.UserException;

public interface UserRegisterDao {
	boolean insertRecord(UserDetails user) throws UserException;
	ArrayList<UserDetails> getUserList() throws UserException;
	
}
