package com.cg.registration.test;

import static org.junit.Assert.*;


import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.registration.entities.UserDetails;
import com.cg.registration.exceptions.UserException;
import com.cg.registration.services.UserService;
import com.cg.registration.services.UserServiceImpl;

public class TestUserRegister {
	private UserService service;

	@Before
	public void setUp() throws Exception {
		service= new UserServiceImpl();
	}

	@After
	public void tearDown() throws Exception {
		service= null;
	}

	@Test
	public void testInsertRecord() {
		UserDetails user1= new UserDetails("Pratiksha", "Nakti", "abcd", 'F', "Mumbai", "Java, .NET");
		try {
			boolean res= service.insertRecord(user1);
			assertEquals(true, res);
		} catch (UserException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
