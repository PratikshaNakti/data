package com.cg.registration.controller;

import java.io.IOException;





import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.registration.entities.UserDetails;
import com.cg.registration.exceptions.UserException;
import com.cg.registration.services.UserService;
import com.cg.registration.services.UserServiceImpl;


@WebServlet("/addUser")
public class FrontController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	 private UserService services;
	
	@Override
	public void init() throws ServletException {
		// TODO Auto-generated method stub
		try {
			services= new UserServiceImpl();
		} catch (UserException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}
	
	private void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String fname= request.getParameter("fName");
		String lname= request.getParameter("lName");
		String pswrd= request.getParameter("pswd");
		String gender= request.getParameter("gender");
		String[] skills= request.getParameterValues("skill");
		String city= request.getParameter("city");
		
		String allDetails= fname+", "+lname+" , "+pswrd+" , "+gender+" , "+skills+" , "+city;
		//System.out.println(allDetails);
		String skillSet="";
		for(int i=0; i<skills.length; i++){
			skillSet= skillSet.concat(" , ").concat(skills[i]);
		}
		
		char gen;
		if(gender.equals("Male")){
			gen='M';
		}
		else{
			gen='F';
		}
		
		UserDetails users= new UserDetails();
		users.setFirstName(fname);
		users.setLastName(lname);
		users.setPassword(pswrd);
		users.setGender(gen);
		users.setSkills(skillSet);
		users.setCity(city);
		
		
		//UserDetails users= new UserDetails(fname, lname, pswrd, gen, city, skillSet);
		try {
			boolean flag= services.insertRecord(users);
			if(flag==true){
				System.out.println("Add user successful");
				
				//show all users details
				ArrayList<UserDetails> userList;
				userList= services.getUserList();
				
				request.setAttribute("details", userList);
				RequestDispatcher disp= request.getRequestDispatcher("successPage.jsp");
				disp.forward(request, response);
				//response.sendRedirect("success.html");
			}
			else{
				System.out.println("Add User Failed");
				RequestDispatcher disp= request.getRequestDispatcher("error.jsp");
				//response.sendRedirect("failure.html");
			}
		} catch (UserException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("AddUser Excptn at Controller");
		}
		
		
	}

}
