package com.cg.registration.services;

import java.util.ArrayList;

import com.cg.registration.entities.UserDetails;
import com.cg.registration.exceptions.UserException;

public interface UserService {

	boolean insertRecord(UserDetails user) throws UserException;
	ArrayList<UserDetails> getUserList() throws UserException;
}
