package com.cg.registration.dao;

import com.cg.registration.entities.UserDetails;
import com.cg.registration.exceptions.UserException;

public interface UserRegisterDao {
	boolean insertRecord(UserDetails user) throws UserException;
	
	
}
