package com.cg.registration.dao;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.cg.registration.entities.UserDetails;
import com.cg.registration.exceptions.UserException;
import com.cg.registration.util.JdbcUtil;



public class UserRegisterDaoImpl implements UserRegisterDao {
	//private JndiUtil util;
	private JdbcUtil util;

	public UserRegisterDaoImpl() throws UserException {
		//util= new JndiUtil();
		util= new JdbcUtil();
		
	}

	@Override
	public boolean insertRecord(UserDetails user) throws UserException {
		Connection connect= null;
		PreparedStatement stmt1= null;
		
		int rec_ins=0;
		
		String fName= user.getFirstName();
		String lName= user.getLastName();
		String pswd= user.getPassword();
		char gender= user.getGender();
		String skillSet= user.getSkills();
		String city= user.getCity();
		
		/*String skillSet= "";
		for(int i=0; i<skill.length; i++){
			String skillIndexValue= skill[i];
			skillSet= skillSet.concat(skillIndexValue+", ");
		}
		
*/		String insQry="INSERT INTO RegisteredUsers (firstname, lastname, password, gender, skillset, city) VALUES (?,?,?,?,?,?)";
		try {
			connect= util.getConnection();
			stmt1= connect.prepareStatement(insQry);
			stmt1.setString(1, fName);
			stmt1.setString(2, lName);
			stmt1.setString(3, pswd);
			stmt1.setString(4, String.valueOf(gender));
			stmt1.setString(5, skillSet);
			stmt1.setString(6, city);
			 rec_ins= stmt1.executeUpdate();
			 
			 if(rec_ins>0){
				 return true;
			 }
			 else{
				 throw new UserException("Record insertion failed.");
			 }
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new UserException("JDBC failed.", e);
		}
		
		
	}

}
