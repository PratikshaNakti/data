package com.cg.registration.services;

import com.cg.registration.entities.UserDetails;
import com.cg.registration.exceptions.UserException;

public interface UserService {

	boolean insertRecord(UserDetails user) throws UserException;
}
