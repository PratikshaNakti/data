package com.cg.registration.services;

import com.cg.registration.dao.UserRegisterDao;
import com.cg.registration.dao.UserRegisterDaoImpl;
import com.cg.registration.entities.UserDetails;
import com.cg.registration.exceptions.UserException;

public class UserServiceImpl implements UserService {
	private UserRegisterDao dao;

	public UserServiceImpl() throws UserException {
		dao= new UserRegisterDaoImpl();
	}

	@Override
	public boolean insertRecord(UserDetails user) throws UserException {
		
		return dao.insertRecord(user);
	}

}
