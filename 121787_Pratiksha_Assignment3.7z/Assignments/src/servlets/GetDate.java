package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.time.LocalDate;



import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sun.mail.iap.Response;

/**
 * Servlet implementation class GetDate
 */
@WebServlet("/date")
public class GetDate extends HttpServlet {
	PrintWriter out;
	private static final long serialVersionUID = 1L;
       

	@Override
	public void init() throws ServletException {
	
	
		System.out.println("Servlet- Init");
	}
 
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out= response.getWriter();
		SimpleDateFormat sdfDt= new SimpleDateFormat("yyyy-MM-dd 'at' hh:mm:ss a zzz");
		Date dnow= new Date();
		String disp= sdfDt.format(dnow);
		
		
		out.write("Current date is :");
		out.write(disp);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response );
	}

}
